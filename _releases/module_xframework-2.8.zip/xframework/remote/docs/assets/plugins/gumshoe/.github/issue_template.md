<!-- Thanks for submitting an issue! All bug reports and problem issues require a **reduced test case**. Create one forking the CodePen linked below. See the guidelines link above for more details. -->

**Test case:** https://codepen.io/cferdinandi/pen/oVjRbL